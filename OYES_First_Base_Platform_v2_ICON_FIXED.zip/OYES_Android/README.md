# OYES — First Free Base Platform

## Home
1. 🎬 Cinema
2. 🏠 Accommodation
3. 💼 Local Jobs & Services
4. 🆘 Help Desk / Charity

## Cinema
- Acting
- Technical
- Direction
- Writing
- Music
- Production / Producers
- Audition / Casting / Film opportunities
- OYES Productions visual + supplied clapperboard visual

## Accommodation
- Family
- Bachelor
- Ladies / Gents
- House / Room / Flat / Apartment
- Hostel / PG / Homestay
- Workers / Students
- Short-term / Long-term
- Parking / Other

## Local Jobs & Services
- Plumbing
- Electrical / Wiring
- Mason / Construction
- Labour
- Carpenter
- Painting
- Cleaning
- Coconut climbing
- Tree work
- Farming / Gardening
- Welding
- AC / Refrigerator technician
- Tiles / Marble
- Water tank / Pump
- Driver / Delivery
- Other local services

## Help Desk
- +91 99471 98248
- +91 91421 00100
- directorsalihwayanad@gmail.com

The current version is intentionally a simple, mostly offline foundation. It uses the phone's normal Dialer and Email apps for direct contact. Online database, login, image/video storage, search, moderation, notifications and other paid infrastructure can be added later one by one.
