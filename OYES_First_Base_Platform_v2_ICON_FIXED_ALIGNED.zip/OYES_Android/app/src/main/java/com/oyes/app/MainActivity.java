package com.oyes.app;

import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.util.TypedValue;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    final int BLACK = Color.rgb(8,8,8);
    final int GOLD = Color.rgb(214,173,85);
    final int CREAM = Color.rgb(255,248,231);
    final int CARD = Color.rgb(23,19,13);

    LinearLayout root, content;

    int dp(float value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    TextView text(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(20), dp(12), dp(20), dp(12));
        return t;
    }

    GradientDrawable bg(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(radius);
        g.setStroke(1, GOLD);
        return g;
    }

    Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(CREAM);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setIncludeFontPadding(false);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(14), dp(8), dp(14), dp(8));
        b.setBackground(bg(CARD, dp(14)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(76));
        p.setMargins(0, dp(6), 0, dp(6));
        b.setLayoutParams(p);
        return b;
    }

    void base() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BLACK);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(dp(12),dp(8),dp(12),dp(8));
        top.setBackgroundColor(BLACK);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.oyes.app.R.drawable.oyes_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        top.addView(logo, new LinearLayout.LayoutParams(dp(56),dp(56)));

        TextView title = text("OYES", 26, GOLD);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        top.addView(title, new LinearLayout.LayoutParams(0,dp(56),1));

        root.addView(top);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(10), dp(20), dp(30));
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    void showHome() {
        base();

        // Simple first screen: open OYES, choose a section, and move on quickly.
        ImageView hero = new ImageView(this);
        hero.setImageResource(R.drawable.oyes_logo);
        hero.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, dp(150));
        hp.setMargins(0, 0, 0, dp(4));
        hero.setLayoutParams(hp);
        content.addView(hero);

        TextView welcome = text("OYES", 30, GOLD);
        welcome.setGravity(Gravity.CENTER);
        welcome.setTypeface(null, android.graphics.Typeface.BOLD);
        content.addView(welcome);

        TextView tagline = text("തുറക്കുക → വേണ്ടത് തിരഞ്ഞെടുക്കുക → ഉടൻ ബന്ധപ്പെടുക", 16, CREAM);
        tagline.setGravity(Gravity.CENTER);
        content.addView(tagline);
        content.addView(text("കേരളം മുഴുവൻ ആളുകളെയും അവസരങ്ങളെയും ബന്ധിപ്പിക്കുന്ന ലളിതമായ പ്ലാറ്റ്ഫോം", 13, Color.LTGRAY));

        Button cinema = button("🎬  സിനിമ\nഅഭിനയം • അവസരങ്ങൾ • ടെക്നിക്കൽ");
        cinema.setTextSize(17);
        cinema.setOnClickListener(v -> showCategory("cinema"));
        content.addView(cinema);

        Button stay = button("🏠  താമസസൗകര്യം\nFamily • Room • Flat • Hostel • PG");
        stay.setTextSize(17);
        stay.setOnClickListener(v -> showCategory("stay"));
        content.addView(stay);

        Button jobs = button("💼  ജോലി / നാട്ടുസേവനം\nജോലി • തൊഴിലാളി • Local Services");
        jobs.setTextSize(17);
        jobs.setOnClickListener(v -> showCategory("jobs"));
        content.addView(jobs);

        Button help = button("🆘  Help Desk / Charity\nസഹായം ആവശ്യമുണ്ടോ? നേരിട്ട് ബന്ധപ്പെടുക");
        help.setTextSize(17);
        help.setOnClickListener(v -> showHelpDesk());
        content.addView(help);

        TextView footer = text("OYES — ആദ്യഘട്ടം സൗജന്യമായി.\nപിന്നീട് Search, District, Profiles, Photos, Notifications തുടങ്ങിയ സൗകര്യങ്ങൾ ചേർക്കാം.", 13, Color.LTGRAY);
        footer.setGravity(Gravity.CENTER);
        content.addView(footer);
    }

    void showHelpDesk() {
        base();

        Button back = button("←  OYES Home");
        back.setOnClickListener(v -> showHome());
        content.addView(back);

        TextView h = text("🆘  OYES HELP DESK", 25, GOLD);
        h.setTypeface(null, android.graphics.Typeface.BOLD);
        h.setGravity(Gravity.CENTER);
        content.addView(h);

        content.addView(text(
            "സഹായം ആവശ്യമുണ്ടെങ്കിൽ താഴെയുള്ള നമ്പറുകളിലേക്ക് നേരിട്ട് വിളിക്കാം.\n" +
            "OYES-ന് സാധിക്കുന്ന സഹായങ്ങൾ ഏകോപിപ്പിക്കാൻ ഈ Help Desk ഉപയോഗിക്കാം.",
            16, CREAM));

        Button call1 = button("📞  +91 99471 98248");
        call1.setOnClickListener(v -> callNumber("+919947198248"));
        content.addView(call1);

        Button call2 = button("📞  +91 91421 00100");
        call2.setOnClickListener(v -> callNumber("+919142100100"));
        content.addView(call2);

        Button email = button("✉️  directorsalihwayanad@gmail.com");
        email.setOnClickListener(v -> sendEmail());
        content.addView(email);

        content.addView(text(
            "\n❤️ Charity / സഹായം\n" +
            "താമസം, ജോലി, സാമൂഹിക സഹായം തുടങ്ങിയ കാര്യങ്ങളിൽ OYES-ന് സാധിക്കുന്ന സഹായങ്ങൾ കണ്ടെത്താനും ഏകോപിപ്പിക്കാനും ഈ വിഭാഗം ഉപയോഗിക്കാം.",
            15, CREAM));
    }

    void callNumber(String number) {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:" + number));
        startActivity(intent);
    }

    void sendEmail() {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:directorsalihwayanad@gmail.com"));
        intent.putExtra(Intent.EXTRA_SUBJECT, "OYES Help Desk");
        startActivity(Intent.createChooser(intent, "Email"));
    }

    void showCategory(String type) {
        if (type.equals("cinema")) {
            showCinema();
            return;
        }
        base();
        Button back = button("←  തിരികെ");
        back.setOnClickListener(v -> showHome());
        content.addView(back);

        String title;
        if (type.equals("stay")) title = "🏠 താമസസൗകര്യം";
        else if (type.equals("jobs")) title = "💼 ജോലി അവസരങ്ങൾ";
        else title = "🎬 സിനിമ";
        TextView h = text(title, 24, GOLD);
        h.setTypeface(null, android.graphics.Typeface.BOLD);
        content.addView(h);

        String desc = type.equals("stay")
                ? "കേരളത്തിലെ ഏത് ജില്ലയിലും Family / വ്യക്തിഗത താമസസൗകര്യങ്ങൾ കണ്ടെത്താം."
                : type.equals("jobs")
                ? "ആളുകളെ ആവശ്യമുള്ള ജോലികൾ പ്രസിദ്ധീകരിക്കാം; ജോലി അന്വേഷിക്കുന്നവർക്ക് ബന്ധപ്പെടാം."
                : "അഭിനയ താൽപര്യമുള്ളവർക്കും അഭിനേതാക്കളെ അന്വേഷിക്കുന്ന Producers-ക്കും അവസരങ്ങൾ പങ്കിടാം.";
        content.addView(text(desc, 15, CREAM));

        Button add = button("+  പുതിയ പോസ്റ്റ് ചേർക്കുക");
        add.setOnClickListener(v -> showForm(type));
        content.addView(add);

        content.addView(text("\nഉദാഹരണ വിഭാഗങ്ങൾ", 18, GOLD));
        if (type.equals("stay")) {
            content.addView(text("• കോഴിക്കോട് — Family താമസം\n• വയനാട് — താമസ സൗകര്യം\n• എറണാകുളം — Working family accommodation", 15, CREAM));
        } else if (type.equals("jobs")) {
            content.addView(text("• Hotel / Restaurant staff\n• Driver / Delivery\n• Construction / Office jobs", 15, CREAM));
        } else {
            content.addView(text(
                "🎭 അഭിനയം\nActor • Actress • Child Artist • Supporting Artist • Character Artist\n\n" +
                "🎬 സംവിധാനം\nDirector • Assistant Director\n\n" +
                "✍️ എഴുത്ത്\nStory • Screenplay • Dialogue • Script Writer\n\n" +
                "🎥 ടെക്നിക്കൽ\nCamera • Cinematography • Editing • Sound • Dubbing • VFX • Graphics • Colorist • Lighting • Makeup • Costume • Art Department\n\n" +
                "🎵 സംഗീതം\nMusic Director • Singer • Lyricist • Musician\n\n" +
                "💃 കലാകാരന്മാർ\nDancer • Choreographer • Stunt Artist • Fight Master\n\n" +
                "💰 നിർമ്മാണം\nProducer • Production House • Production Manager • Production Staff\n\n" +
                "📢 അവസരങ്ങൾ\nAudition • Casting Call • Film Jobs • Projects • Equipment • Studio • Locations",
                15, CREAM));
        }
    }

    void showCinema() {
        base();

        Button back = button("←  OYES Home");
        back.setOnClickListener(v -> showHome());
        content.addView(back);

        // Cinema opening visuals: the supplied OYES Productions eagle and the
        // supplied clapperboard image are shown prominently when Cinema opens.
        ImageView productions = new ImageView(this);
        productions.setImageResource(R.drawable.oyes_productions);
        productions.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(-1, dp(250));
        p1.setMargins(0, dp(6), 0, dp(8));
        productions.setLayoutParams(p1);
        content.addView(productions);

        TextView h = text("🎬  OYES MOVIE", 26, GOLD);
        h.setGravity(Gravity.CENTER);
        h.setTypeface(null, android.graphics.Typeface.BOLD);
        content.addView(h);

        ImageView clapper = new ImageView(this);
        clapper.setImageResource(R.drawable.movie_clapper_person);
        clapper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(-1, dp(300));
        p2.setMargins(0, dp(6), 0, dp(12));
        clapper.setLayoutParams(p2);
        content.addView(clapper);

        content.addView(text("സിനിമാ മേഖലയിലെ എല്ലാ അവസരങ്ങളും ഒരിടത്ത്", 16, CREAM));

        Button acting = button("🎭  അഭിനയം");
        acting.setOnClickListener(v -> showCinemaSub("acting"));
        content.addView(acting);

        Button technical = button("🎥  ടെക്നിക്കൽ");
        technical.setOnClickListener(v -> showCinemaSub("technical"));
        content.addView(technical);

        Button direction = button("🎬  സംവിധാനം");
        direction.setOnClickListener(v -> showCinemaSub("direction"));
        content.addView(direction);

        Button writing = button("✍️  എഴുത്ത്");
        writing.setOnClickListener(v -> showCinemaSub("writing"));
        content.addView(writing);

        Button music = button("🎵  സംഗീതം");
        music.setOnClickListener(v -> showCinemaSub("music"));
        content.addView(music);

        Button production = button("💰  നിർമ്മാണം / Producers");
        production.setOnClickListener(v -> showCinemaSub("production"));
        content.addView(production);

        Button opportunities = button("📢  Audition / Casting / സിനിമാ അവസരങ്ങൾ");
        opportunities.setOnClickListener(v -> showCinemaSub("opportunities"));
        content.addView(opportunities);
    }

    void showCinemaSub(String sub) {
        base();
        Button back = button("←  സിനിമയിലേക്ക്");
        back.setOnClickListener(v -> showCinema());
        content.addView(back);

        String title = "സിനിമ";
        String list = "";
        if (sub.equals("acting")) {
            title = "🎭 അഭിനയം";
            list = "Actor • Actress • Child Artist • Supporting Artist • Character Artist";
        } else if (sub.equals("technical")) {
            title = "🎥 ടെക്നിക്കൽ";
            list = "Camera • Cinematography • Editing • Sound • Dubbing • VFX • Graphics • Colorist • Lighting • Makeup • Costume • Art Department";
        } else if (sub.equals("direction")) {
            title = "🎬 സംവിധാനം";
            list = "Director • Assistant Director • Associate Director";
        } else if (sub.equals("writing")) {
            title = "✍️ എഴുത്ത്";
            list = "Story • Screenplay • Dialogue • Script Writer";
        } else if (sub.equals("music")) {
            title = "🎵 സംഗീതം";
            list = "Music Director • Singer • Lyricist • Musician";
        } else if (sub.equals("production")) {
            title = "💰 നിർമ്മാണം";
            list = "Producer • Production House • Production Manager • Production Staff • Production Services";
        } else {
            title = "📢 അവസരങ്ങൾ";
            list = "Audition • Casting Call • Film Jobs • Projects • Equipment • Studio • Locations";
        }

        TextView h = text(title, 24, GOLD);
        h.setTypeface(null, android.graphics.Typeface.BOLD);
        content.addView(h);
        content.addView(text(list, 16, CREAM));

        Button add = button("+  പുതിയ പോസ്റ്റ് / അവസരം ചേർക്കുക");
        add.setOnClickListener(v -> showForm("cinema"));
        content.addView(add);
    }

    void showForm(String type) {
        base();
        Button back = button("←  തിരികെ");
        back.setOnClickListener(v -> showCategory(type));
        content.addView(back);

        content.addView(text("പുതിയ പോസ്റ്റ്", 24, GOLD));
        EditText name = field("പേര് / സ്ഥാപനത്തിന്റെ പേര്");
        EditText place = field("സ്ഥലം / ജില്ല");
        EditText details = field(type.equals("stay") ? "താമസത്തിന്റെ വിശദാംശങ്ങൾ"
                : type.equals("jobs") ? "ജോലിയുടെ വിശദാംശങ്ങൾ"
                : "പ്രൊഫൈൽ / സിനിമാ അവസരത്തിന്റെ വിശദാംശങ്ങൾ");
        EditText phone = field("ഫോൺ നമ്പർ");

        content.addView(name); content.addView(place); content.addView(details); content.addView(phone);

        Button save = button("✓  പോസ്റ്റ് തയ്യാറാക്കുക");
        save.setOnClickListener(v -> Toast.makeText(this,
                "ഇത് ഇപ്പോൾ Demo ആണ്. അടുത്ത പതിപ്പിൽ പോസ്റ്റ് database-ൽ save ചെയ്യാം.",
                Toast.LENGTH_LONG).show());
        content.addView(save);
    }

    EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setHintTextColor(Color.GRAY); e.setTextColor(CREAM);
        e.setTextSize(15); e.setPadding(dp(18), dp(10), dp(18), dp(10));
        e.setBackground(bg(Color.rgb(20,20,20), dp(18)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(58));
        p.setMargins(0, dp(8), 0, dp(8)); e.setLayoutParams(p);
        return e;
    }
}
