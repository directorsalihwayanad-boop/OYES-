package com.oyes.app;

import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.util.TypedValue;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    final int BLACK = Color.rgb(8,8,8);
    final int GOLD = Color.rgb(214,173,85);
    final int CREAM = Color.rgb(255,248,231);
    final int CARD = Color.rgb(23,19,13);

    LinearLayout root, content;

    int dp(float value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    TextView text(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(20), dp(12), dp(20), dp(12));
        return t;
    }

    GradientDrawable bg(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(radius);
        g.setStroke(1, GOLD);
        return g;
    }

    Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(CREAM);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setIncludeFontPadding(true);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(14), dp(8), dp(14), dp(8));
        b.setBackground(bg(CARD, dp(14)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(62));
        p.setMargins(0, dp(6), 0, dp(6));
        b.setLayoutParams(p);
        return b;
    }

    void base() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BLACK);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(dp(12),dp(8),dp(12),dp(8));
        top.setBackgroundColor(BLACK);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.oyes.app.R.drawable.oyes_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        top.addView(logo, new LinearLayout.LayoutParams(dp(56),dp(56)));

        TextView title = text("OYES", 26, GOLD);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        top.addView(title, new LinearLayout.LayoutParams(0,dp(56),1));

        root.addView(top);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(10), dp(20), dp(30));
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    void showHome() {
        base();

        // Simple first screen: open OYES, choose a section, and move on quickly.
        ImageView hero = new ImageView(this);
        hero.setImageResource(R.drawable.oyes_logo);
        hero.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, dp(150));
        hp.setMargins(0, 0, 0, dp(4));
        hero.setLayoutParams(hp);
        content.addView(hero);

        TextView welcome = text("OYES", 30, GOLD);
        welcome.setGravity(Gravity.CENTER);
        welcome.setTypeface(null, android.graphics.Typeface.BOLD);
        content.addView(welcome);

        TextView tagline = text("Open → Choose what you need → Connect instantly", 16, CREAM);
        tagline.setGravity(Gravity.CENTER);
        content.addView(tagline);
        content.addView(text("A simple platform connecting people and opportunities across Kerala", 13, Color.LTGRAY));

        Button cinema = button("🎬  Cinema\nActing • Opportunities • Technical");
        cinema.setTextSize(15);
        cinema.setOnClickListener(v -> showCategory("cinema"));
        content.addView(cinema);

        Button stay = button("🏠  Accommodation\nFamily • Room • Flat • Hostel • PG");
        stay.setTextSize(15);
        stay.setOnClickListener(v -> showCategory("stay"));
        content.addView(stay);

        Button jobs = button("💼  Jobs / Local Services\nJobs • Workers • Local Services");
        jobs.setTextSize(15);
        jobs.setOnClickListener(v -> showCategory("jobs"));
        content.addView(jobs);

        Button help = button("🆘  Help Desk / Charity\nNeed help? Contact us directly");
        help.setTextSize(15);
        help.setOnClickListener(v -> showHelpDesk());
        content.addView(help);

        TextView footer = text("OYES — Free during the first stage.\nLater we can add Search, Districts, Profiles, Photos, Notifications and more.", 13, Color.LTGRAY);
        footer.setGravity(Gravity.CENTER);
        content.addView(footer);
    }

    void showHelpDesk() {
        base();

        Button back = button("←  OYES Home");
        back.setOnClickListener(v -> showHome());
        content.addView(back);

        TextView h = text("🆘  OYES HELP DESK", 25, GOLD);
        h.setTypeface(null, android.graphics.Typeface.BOLD);
        h.setGravity(Gravity.CENTER);
        content.addView(h);

        content.addView(text(
            "If you need help, call one of the numbers below directly.\n" +
            "This Help Desk can coordinate support that OYES can provide.",
            16, CREAM));

        Button call1 = button("📞  +91 99471 98248");
        call1.setOnClickListener(v -> callNumber("+919947198248"));
        content.addView(call1);

        Button call2 = button("📞  +91 91421 00100");
        call2.setOnClickListener(v -> callNumber("+919142100100"));
        content.addView(call2);

        Button email = button("✉️  directorsalihwayanad@gmail.com");
        email.setOnClickListener(v -> sendEmail());
        content.addView(email);

        content.addView(text(
            "\n❤️ Charity / Support\n" +
            "OYES can help identify and coordinate available support for accommodation, jobs and social needs.",
            15, CREAM));
    }

    void callNumber(String number) {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:" + number));
        startActivity(intent);
    }

    void sendEmail() {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:directorsalihwayanad@gmail.com"));
        intent.putExtra(Intent.EXTRA_SUBJECT, "OYES Help Desk");
        startActivity(Intent.createChooser(intent, "Email"));
    }

    void showCategory(String type) {
        if (type.equals("cinema")) {
            showCinema();
            return;
        }
        base();
        Button back = button("←  Back");
        back.setOnClickListener(v -> showHome());
        content.addView(back);

        String title;
        if (type.equals("stay")) title = "🏠 Accommodation";
        else if (type.equals("jobs")) title = "💼 Job Opportunities";
        else title = "🎬 Cinema";
        TextView h = text(title, 24, GOLD);
        h.setTypeface(null, android.graphics.Typeface.BOLD);
        content.addView(h);

        String desc = type.equals("stay")
                ? "Find Family or personal accommodation in any district of Kerala."
                : type.equals("jobs")
                ? "Publish jobs for people who need workers and connect with job seekers."
                : "Share opportunities for actors and Producers looking for talent.";
        content.addView(text(desc, 15, CREAM));

        Button add = button("+  Add New Post");
        add.setOnClickListener(v -> showForm(type));
        content.addView(add);

        content.addView(text("\nExample Categories", 18, GOLD));
        if (type.equals("stay")) {
            content.addView(text("• Kozhikode — Family accommodation\n• Wayanad — Accommodation\n• Ernakulam — Working family accommodation", 15, CREAM));
        } else if (type.equals("jobs")) {
            content.addView(text("• Hotel / Restaurant staff\n• Driver / Delivery\n• Construction / Office jobs", 15, CREAM));
        } else {
            content.addView(text(
                "🎭 Acting\nActor • Actress • Child Artist • Supporting Artist • Character Artist\n\n" +
                "🎬 Direction\nDirector • Assistant Director\n\n" +
                "✍️ Writing\nStory • Screenplay • Dialogue • Script Writer\n\n" +
                "🎥 Technical\nCamera • Cinematography • Editing • Sound • Dubbing • VFX • Graphics • Colorist • Lighting • Makeup • Costume • Art Department\n\n" +
                "🎵 Music\nMusic Director • Singer • Lyricist • Musician\n\n" +
                "💃 Artists\nDancer • Choreographer • Stunt Artist • Fight Master\n\n" +
                "💰 Production\nProducer • Production House • Production Manager • Production Staff\n\n" +
                "📢 Opportunities\nAudition • Casting Call • Film Jobs • Projects • Equipment • Studio • Locations",
                15, CREAM));
        }
    }

    void showCinema() {
        base();

        Button back = button("←  OYES Home");
        back.setOnClickListener(v -> showHome());
        content.addView(back);

        // Cinema opening visuals: the supplied OYES Productions eagle and the
        // supplied clapperboard image are shown prominently when Cinema opens.
        ImageView productions = new ImageView(this);
        productions.setImageResource(R.drawable.oyes_productions);
        productions.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(-1, dp(250));
        p1.setMargins(0, dp(6), 0, dp(8));
        productions.setLayoutParams(p1);
        content.addView(productions);

        TextView h = text("🎬  OYES MOVIE", 26, GOLD);
        h.setGravity(Gravity.CENTER);
        h.setTypeface(null, android.graphics.Typeface.BOLD);
        content.addView(h);

        ImageView clapper = new ImageView(this);
        clapper.setImageResource(R.drawable.movie_clapper_person);
        clapper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(-1, dp(300));
        p2.setMargins(0, dp(6), 0, dp(12));
        clapper.setLayoutParams(p2);
        content.addView(clapper);

        content.addView(text("All opportunities in the film industry in one place", 16, CREAM));

        Button acting = button("🎭  Acting");
        acting.setOnClickListener(v -> showCinemaSub("acting"));
        content.addView(acting);

        Button technical = button("🎥  Technical");
        technical.setOnClickListener(v -> showCinemaSub("technical"));
        content.addView(technical);

        Button direction = button("🎬  Direction");
        direction.setOnClickListener(v -> showCinemaSub("direction"));
        content.addView(direction);

        Button writing = button("✍️  Writing");
        writing.setOnClickListener(v -> showCinemaSub("writing"));
        content.addView(writing);

        Button music = button("🎵  Music");
        music.setOnClickListener(v -> showCinemaSub("music"));
        content.addView(music);

        Button production = button("💰  Production / Producers");
        production.setOnClickListener(v -> showCinemaSub("production"));
        content.addView(production);

        Button opportunities = button("📢  Audition / Casting / Film Opportunities");
        opportunities.setOnClickListener(v -> showCinemaSub("opportunities"));
        content.addView(opportunities);
    }

    void showCinemaSub(String sub) {
        base();
        Button back = button("←  Back to Cinema");
        back.setOnClickListener(v -> showCinema());
        content.addView(back);

        String title = "Cinema";
        String list = "";
        if (sub.equals("acting")) {
            title = "🎭 Acting";
            list = "Actor • Actress • Child Artist • Supporting Artist • Character Artist";
        } else if (sub.equals("technical")) {
            title = "🎥 Technical";
            list = "Camera • Cinematography • Editing • Sound • Dubbing • VFX • Graphics • Colorist • Lighting • Makeup • Costume • Art Department";
        } else if (sub.equals("direction")) {
            title = "🎬 Direction";
            list = "Director • Assistant Director • Associate Director";
        } else if (sub.equals("writing")) {
            title = "✍️ Writing";
            list = "Story • Screenplay • Dialogue • Script Writer";
        } else if (sub.equals("music")) {
            title = "🎵 Music";
            list = "Music Director • Singer • Lyricist • Musician";
        } else if (sub.equals("production")) {
            title = "💰 Production";
            list = "Producer • Production House • Production Manager • Production Staff • Production Services";
        } else {
            title = "📢 Opportunities";
            list = "Audition • Casting Call • Film Jobs • Projects • Equipment • Studio • Locations";
        }

        TextView h = text(title, 24, GOLD);
        h.setTypeface(null, android.graphics.Typeface.BOLD);
        content.addView(h);
        content.addView(text(list, 16, CREAM));

        Button add = button("+  Add New Post / Opportunity");
        add.setOnClickListener(v -> showForm("cinema"));
        content.addView(add);
    }

    void showForm(String type) {
        base();
        Button back = button("←  Back");
        back.setOnClickListener(v -> showCategory(type));
        content.addView(back);

        content.addView(text("New Post", 24, GOLD));
        EditText name = field("Name / Organization");
        EditText place = field("Place / District");
        EditText details = field(type.equals("stay") ? "Accommodation details"
                : type.equals("jobs") ? "Job details"
                : "Profile / Film opportunity details");
        EditText phone = field("Phone number");

        content.addView(name); content.addView(place); content.addView(details); content.addView(phone);

        Button save = button("✓  Prepare Post");
        save.setOnClickListener(v -> Toast.makeText(this,
                "This is currently a Demo. In the next version, posts can be saved to a database.",
                Toast.LENGTH_LONG).show());
        content.addView(save);
    }

    EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setHintTextColor(Color.GRAY); e.setTextColor(CREAM);
        e.setTextSize(15); e.setPadding(dp(18), dp(10), dp(18), dp(10));
        e.setBackground(bg(Color.rgb(20,20,20), dp(18)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(58));
        p.setMargins(0, dp(8), 0, dp(8)); e.setLayoutParams(p);
        return e;
    }
}
