# OYES Gradle setup

This project uses Android Gradle Plugin 8.6.1 and Gradle 8.10.2.

- `gradlew` is included for Linux/macOS environments.
- `gradlew.bat` is included for Windows.
- The first build requires Internet access to download Gradle 8.10.2 and Android/AndroidX dependencies.

Build command:

    ./gradlew assembleDebug

Windows:

    gradlew.bat assembleDebug
