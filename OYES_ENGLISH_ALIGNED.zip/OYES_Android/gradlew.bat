@echo off
setlocal
set "APP_HOME=%~dp0"
set "DIST=%USERPROFILE%\.gradle\oyes-wrapper\gradle-8.10.2"
if not exist "%DIST%\bin\gradle.bat" (
  echo Gradle 8.10.2 is not installed in the OYES wrapper cache.
  echo Run this project on a machine with Internet access so Gradle can be downloaded.
  exit /b 1
)
call "%DIST%\bin\gradle.bat" -p "%APP_HOME%" %*
