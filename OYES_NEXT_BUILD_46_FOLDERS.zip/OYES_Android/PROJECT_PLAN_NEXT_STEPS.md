# OYES Project — Current Structure and Next Steps

## Current project structure

The existing `OYES_Android` project structure and assets have been retained. The Android app source remains under `app/src/main/`, with Java source, Android manifest, resources, Gradle configuration, and wrapper configuration.

## Change included in this version

- Added a **Sacred Books** section at the very top of the home screen, before Cinema, Accommodation, Jobs/Local Services, and Help Desk.
- Added a Sacred Books page with links for the Holy Quran, Bible, and Bhagavad Gita.
- The links open online reading resources in the phone's browser and require internet access.
- Existing categories, Help Desk contact actions, and supplied visual assets are retained.

## Suggested next development order

1. Verify the Sacred Books links and home-screen layout on a real Android device.
2. Review all existing buttons and forms; note that the current Add New Post form is a demo and does not save data to a server/database.
3. Decide whether posts need a backend, moderation, user accounts, and image uploads before implementing them.
4. Test Help Desk call and email actions on a phone.
5. Build a new APK from this updated source and install-test it before distributing it.

## Important build note

The APK must be rebuilt after source changes. A previously downloaded APK does not automatically include these updates. Keep the previous ZIP and APK as backups until the new build is tested.


## 46-folder prototype update (2026-10-09)
The home screen now lists the agreed 46 main folders in the user-centric order. Each folder has a distinct emoji marker. Existing Sacred Books, Cinema, Jobs, and Help Desk screens are retained and linked where implemented. Other folder pages are placeholders, not complete services. This project has not yet been build-tested; run the Gradle workflow and resolve any build errors before distributing an APK. Backend, secure admin panel, persistent posts, per-folder photography, search, and database integration remain future work.
