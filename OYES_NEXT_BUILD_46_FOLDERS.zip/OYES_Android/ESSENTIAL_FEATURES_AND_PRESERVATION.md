# OYES — Essential Features and Preservation Notes

## Preserve the existing project
- Keep the existing Android project, Gradle configuration, manifest, Java source, resources, launcher icons, and supplied image assets.
- Keep all nested folders and their relative paths intact when packaging or uploading the project.
- Do not delete or replace the existing Cinema section while adding other essential features.

## Essential app priorities
1. Sacred Books must be prominent at the top of the home screen.
2. Sacred Books page includes links to the Holy Quran, Bible, and Bhagavad Gita. These resources open online and need an internet connection.
3. Cinema / OYES Movie must remain available, including Acting, Technical, Direction, Writing, Music, Production / Producers, and Opportunities sections.
4. Keep existing Help Desk call/email actions and existing supplied visual assets.
5. Keep the English UI and existing alignment/spacing improvements.

## Important limitations to check during testing
- Test every button and external link on an Android device.
- Confirm Help Desk call and email actions work on the device.
- The current Add New Post form is a demo and does not save data to a backend/database; do not represent it as a live publishing system.
- Rebuild the APK after changing source files. Keep the previous APK and ZIP as backups until the new build is tested.

## Build workflow
The GitHub Actions workflow should extract the project ZIP, locate `gradlew`, run `assembleDebug`, and upload the generated debug APK artifact. Verify the workflow run and download the artifact only when a new build is needed.
